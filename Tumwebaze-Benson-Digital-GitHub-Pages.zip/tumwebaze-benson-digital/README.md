# Tumwebaze Benson | ICT Educator

A modern, responsive professional website built with Next.js, React and Framer Motion and configured specifically for **free GitHub Pages hosting**.

## Website identity

**Tumwebaze Benson | ICT Educator**

> Learn ICT. Build Digital Skills. Embrace Technology.

The supplied logo is installed at `public/logo.png` and is used throughout the site.

## GitHub Pages deployment

This project is already configured for GitHub Pages static hosting using Next.js `output: 'export'` and GitHub Actions.

### 1. Create a GitHub repository

Create a **public** repository, for example:

```text
Tumwebaze-Benson-Digital
```

Do not add another README or `.gitignore` if you are uploading this complete project.

### 2. Upload the project

Upload all project files to the repository and push them to the `main` branch.

### 3. Enable GitHub Pages

Open:

**Repository → Settings → Pages → Build and deployment → Source → GitHub Actions**

The included workflow `.github/workflows/deploy-pages.yml` will build and deploy the site automatically.

GitHub Pages supports public repositories on GitHub Free. Project sites use the format:

```text
https://YOUR-USERNAME.github.io/Tumwebaze-Benson-Digital/
```

If the repository is named `YOUR-USERNAME.github.io`, the workflow automatically treats it as a user site and uses the root path instead.

### 4. Future updates

Every push to `main` automatically rebuilds and republishes the website.

## Local development

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Local production build

```bash
npm run build
```

The static website is generated in `out/`.

## Important GitHub Pages compatibility

The workflow automatically determines whether the repository is a project site or a user site and sets `NEXT_PUBLIC_BASE_PATH` accordingly. This prevents broken navigation, CSS/JS assets and logo paths when the website is hosted under a repository subdirectory.

## Included sections

- Home
- About
- Services
- Projects
- Resources
- Blog
- Contact
- Responsive navigation
- Framer Motion animations
- SEO metadata
- Open Graph metadata
- PWA manifest
- GitHub Pages deployment workflow

## Contact form

The current contact page is static and GitHub Pages-compatible. GitHub Pages does not provide a server-side form processor. Connect the form to a client-side/serverless form provider such as EmailJS or Formspree if you want submissions delivered to email.

## GitHub Pages note

GitHub Pages is static hosting. Do not put API keys, passwords, private credentials or other secrets in this repository.
