export const site = {
  name: 'Tumwebaze Benson',
  title: 'ICT Educator',
  brand: 'Tumwebaze Benson | ICT Educator',
  tagline: 'Learn ICT. Build Digital Skills. Embrace Technology.',
  description: 'Tumwebaze Benson is an ICT educator focused on digital skills, educational technology, practical learning resources and technology solutions for education.',
  email: 'tmwbzbenson@gmail.com',
  phone: '+256 776 747 621',
  whatsapp: '+256 776 747 621'
};

export const services = [
  { title: 'ICT Education', text: 'Practical ICT instruction, digital literacy and learner-centred technology education.', icon: 'Monitor' },
  { title: 'Digital Skills Training', text: 'Hands-on training that helps learners and educators confidently use modern digital tools.', icon: 'GraduationCap' },
  { title: 'Educational Technology', text: 'Digital learning workflows, LMS concepts, school technology and resource development.', icon: 'Layers3' },
  { title: 'Web & System Development', text: 'Modern websites and education-focused digital systems designed for real-world use.', icon: 'Code2' },
  { title: 'Digital Resources', text: 'Structured teaching materials, revision resources and interactive learning content.', icon: 'BookOpen' },
  { title: 'Technology Consultancy', text: 'Practical guidance for educators and institutions adopting useful digital solutions.', icon: 'Lightbulb' }
];

export const projects = [
  { title: 'St Peter’s Learning Management System', category: 'Educational Technology', description: 'A school-focused digital learning environment concept for resources, learners, teachers and administration.', tags: ['LMS', 'Education', 'Supabase'] },
  { title: 'BENTECH School Report Management System', category: 'School Systems', description: 'A digital reporting workflow concept designed around school assessment, report generation and administration.', tags: ['Reports', 'School Management', 'Digital'] },
  { title: 'Digital Learning Resources', category: 'Content & Training', description: 'Structured ICT and Geography learning resources designed for secondary education and practical classroom use.', tags: ['ICT', 'Geography', 'Resources'] },
  { title: 'Education Website Projects', category: 'Web Development', description: 'Responsive websites and digital identities for schools, education initiatives and technology projects.', tags: ['Web', 'Branding', 'SEO'] }
];

export const resources = [
  { title: 'ICT Learning Resources', type: 'Learning Resource', text: 'Practical digital skills and ICT learning materials for secondary education.' },
  { title: 'Geography Teaching Resources', type: 'Teaching Resource', text: 'Notes, diagrams, fieldwork support and curriculum-aligned geography materials.' },
  { title: 'Digital Teaching Toolkit', type: 'Toolkit', text: 'Ideas and workflows for integrating digital tools into teaching and learning.' },
  { title: 'Educational Technology Guides', type: 'Guide', text: 'Simple guidance for schools and educators adopting technology responsibly.' }
];

export const posts = [
  { title: 'Why Digital Skills Matter in Secondary Education', date: '2026', excerpt: 'A practical look at building digital confidence alongside academic learning.' },
  { title: 'Designing Useful Technology for Schools', date: '2026', excerpt: 'Principles for building school systems around real teaching and administrative workflows.' },
  { title: 'From ICT Lessons to Digital Problem Solving', date: '2026', excerpt: 'Moving beyond software use toward practical digital thinking and creation.' }
];
