import Reveal from './Reveal';
export default function ProjectCard({item,i=0}){return <Reveal delay={i*.06}><article className="card"><span className="eyebrow">{item.category}</span><h3>{item.title}</h3><p>{item.description}</p><div className="tags">{item.tags.map(t=><span className="tag" key={t}>{t}</span>)}</div></article></Reveal>}
