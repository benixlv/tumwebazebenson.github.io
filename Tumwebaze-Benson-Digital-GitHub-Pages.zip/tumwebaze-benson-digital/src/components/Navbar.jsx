'use client';
import Link from 'next/link';
import {Menu, X} from 'lucide-react';
import {useState} from 'react';
import {site} from '@/data/site';
const basePath = process.env.NEXT_PUBLIC_BASE_PATH || '';
export default function Navbar(){const[open,setOpen]=useState(false);const links=[['Home','/'],['About','/about/'],['Services','/services/'],['Projects','/projects/'],['Resources','/resources/'],['Blog','/blog/'],['Contact','/contact/']];return <header className="nav"><div className="container navin"><Link className="brand" href="/"><img src={`${basePath}/logo.png`} alt="Tumwebaze Benson logo"/><span>{site.brand}</span></Link><nav className="links">{links.map(([n,h])=><Link key={h} href={h}>{n}</Link>)}</nav><button className="menu" onClick={()=>setOpen(!open)} aria-label="Toggle navigation">{open?<X/>:<Menu/>}</button></div>{open&&<div style={{padding:'12px 4%',borderTop:'1px solid var(--line)'}}>{links.map(([n,h])=><Link key={h} onClick={()=>setOpen(false)} href={h} style={{display:'block',padding:'12px 0',color:'#d9e2f2'}}>{n}</Link>)}</div>}</header>}
