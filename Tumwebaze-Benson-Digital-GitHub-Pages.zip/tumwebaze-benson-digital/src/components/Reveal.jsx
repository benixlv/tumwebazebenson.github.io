'use client';
import {motion} from 'framer-motion';
export default function Reveal({children,delay=0}){return <motion.div initial={{opacity:0,y:22}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:.15}} transition={{duration:.55,delay}}>{children}</motion.div>}
