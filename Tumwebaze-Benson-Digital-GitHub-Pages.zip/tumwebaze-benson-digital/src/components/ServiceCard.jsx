import {Monitor,GraduationCap,Layers3,Code2,BookOpen,Lightbulb} from 'lucide-react';
import Reveal from './Reveal';
const icons={Monitor,GraduationCap,Layers3,Code2,BookOpen,Lightbulb};
export default function ServiceCard({item,i=0}){const Icon=icons[item.icon]||Monitor;return <Reveal delay={i*.06}><article className="card"><div className="icon"><Icon size={21}/></div><h3>{item.title}</h3><p>{item.text}</p></article></Reveal>}
