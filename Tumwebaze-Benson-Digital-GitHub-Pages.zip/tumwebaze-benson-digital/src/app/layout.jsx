import './globals.css';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import {site} from '@/data/site';
export const metadata={title:site.brand,description:site.description,keywords:['Tumwebaze Benson','ICT Educator','digital skills','educational technology','ICT Uganda'],openGraph:{title:site.brand,description:site.description,type:'website'}};
export default function RootLayout({children}){return <html lang="en"><body><Navbar/><main>{children}</main><Footer/></body></html>}
